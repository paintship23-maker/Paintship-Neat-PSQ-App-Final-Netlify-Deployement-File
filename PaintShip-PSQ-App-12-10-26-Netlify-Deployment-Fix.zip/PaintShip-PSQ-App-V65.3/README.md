# PaintShip PSQ App — V58 Netlify Source Package

React + Vite single-page app for PaintShip painting estimation, including interior/exterior finishes and wood/metal/joinery.

## Netlify deployment

This source package includes `netlify.toml` with the Vite build command, `dist` publish directory, Node 20, and SPA fallback routing.

1. Extract the ZIP.
2. In Netlify, connect/import the extracted source through a Git repository, or use the Netlify CLI from this folder.
3. Set the required `VITE_FIREBASE_*` values in Netlify Site configuration if Firebase phone authentication is intended. See `env.example` for variable names. Do not commit real credentials.
4. Run `npm ci` and `npm run build` locally before release, or let Netlify run the configured build.
5. Verify the deployed site using the release acceptance checklist in `QA-V58-FINAL.txt`.

**Important:** This is the application source package, not a prebuilt `dist` bundle. A clean production build could not be confirmed in the current environment because dependency installation timed out. Do not use Netlify's manual drag-and-drop deploy with this source ZIP; it expects built static files. Use a Git-connected build or Netlify CLI.

## Local development

```bash
npm ci
npm run dev
```

## Production build

```bash
npm run build
npm run preview
```

## V58 joinery calculation

For catalog-backed wood/metal/joinery material rates, the material amount is area × saved base rate per sq.ft. per coat × coat count. Joinery labour is excluded from the joinery material subtotal. The coat selector accepts numbered coat labels and a numeric Custom count.

Acceptance example: 4 ft × 7 ft = 28 sq.ft.; ₹30/sq.ft./coat gives ₹840 for 1 coat, ₹1,680 for 2 coats, and ₹2,520 for 3 coats.

## Production limitations to resolve before real customer use

- Review Firebase configuration and authentication settings for the intended production environment.
- Confirm persistence/backend configuration and data retention before relying on project data across devices.
- Demo/supervisor/admin credentials and authorization logic must be reviewed before public production access.

## V58 wallpaper, waterproofing, and evidence fixes

- Wallpaper totals and quotation PDF now read the same live `wpItems` records and calculation path.
- Wallpaper roll dimensions are entered in metres, so roll coverage is converted to square feet for the required-roll calculation.
- Zero-valued waterproofing dimensions/rates render as blank inputs to avoid a leading zero while typing.
- Quotation and agreement PDFs collect evidence photos saved in the project and nested Interior/Exterior/Waterproofing sections.
- The favicon uses supplied PaintShip/PSQ logo artwork.

See `QA-V58-FIXES.txt` for changes, source-level checks, limitations, and release acceptance tests.


## V59 release notes
See `V59-CHANGELOG.txt` and `QA-V59-VERIFICATION.txt`. The parser check passed; a production build and live backend/browser tests remain pending because dependencies could not be installed in this environment.
