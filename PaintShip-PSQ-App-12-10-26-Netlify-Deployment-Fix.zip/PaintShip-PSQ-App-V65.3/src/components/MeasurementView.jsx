import React from "react";
import { C } from "./shared.jsx";
import ProfessionalIcon from "./ProfessionalIcon.jsx";

const CARD = { background:C.white, borderRadius:14, padding:"16px 18px", marginBottom:10, border:`1px solid ${C.border}` };

export default function MeasurementView({
  project, up,
  floor, room, af, ar, setAf, setAr, upRoom,
  withMat, inr, calcRoom, calcNet, addRoom, addFloor,
  showInterior,
  doorWindowCalc, polishCalc,
  MeasurementHeader, RoomEditor, ExteriorModule, JoineryModule,
  WallpaperMeasurementTab, TextureMeasurementTab, WaterproofingMeasurementTab,
  defExterior, defExteriorConfig,
}) {
  return <>
    {/* ── Measurement Type selector ── */}
    {(()=>{
      const rawMT = project.measureType || "interior";
      const mt = (rawMT==="polish"||rawMT==="doorwindow") ? "joinery" : rawMT;
      const setMT = v => up(p=>({...p, measureType:v}));
      const TYPES = [
        {id:"interior", icon:"home", label:"Interior"},
        {id:"exterior", icon:"building", label:"Exterior"},
        {id:"joinery",  icon:"door", label:"Wood, Metal & Joinery"},
        {id:"wallpaper", icon:"image", label:"Wallpaper"},
        {id:"texture", icon:"layers", label:"Texture"},
        {id:"waterproofing", icon:"shield", label:"Waterproofing"},
      ];
      return <div style={{display:"flex",gap:6,marginBottom:14,flexWrap:"wrap"}}>
        {TYPES.map(tp=>{
          const sel = mt===tp.id;
          return <button key={tp.id} onClick={()=>setMT(tp.id)}
            style={{flex:"1 1 auto",padding:"11px 8px",borderRadius:12,fontSize:12,fontWeight:700,
              cursor:"pointer",border:`2px solid ${sel?C.navy:C.border}`,
              background:sel?C.navy:"#F8FAFC",color:sel?"#fff":C.gray,
              display:"flex",alignItems:"center",justifyContent:"center",gap:6,
              transition:"all 0.15s"}}>
            <ProfessionalIcon name={tp.icon} size={16} />{tp.label}
          </button>;
        })}
      </div>;
    })()}

    {/* ── Interior ── */}
    {(project.measureType||"interior")==="interior"&&<>
      {showInterior&&floor&&room&&<div style={{...CARD,padding:"12px 14px"}}>
        <MeasurementHeader
          project={project} floor={floor} room={room}
          af={af} ar={ar} setAf={setAf} setAr={setAr}
          upRoom={upRoom} withMat={withMat} inr={inr}
          calcRoom={calcRoom} calcNet={calcNet} addRoom={addRoom} addFloor={addFloor}
          up={up}
        />
        <RoomEditor room={room} onUpdate={upRoom} quoteMode={project.quoteMode} category={project.category} projectType={project.projectType || "fresh"}
          onTransferToJoinery={(opening, context) => up(p => {
            const sourceId = opening?.id;
            const exists = (p.doorWindowItems || []).some(it => it.sourceAdjustmentId === sourceId && sourceId);
            if (exists) return p;
            const kind = opening.kind === "Window" ? "Window" : opening.kind === "Sliding Door" ? "Door" : opening.kind === "Wardrobe" ? "Wardrobe" : opening.kind === "Furniture" || opening.kind === "TV Unit" ? "Furniture" : "Door";
            const item = {
              id: `JOINERY-${Date.now()}-${Math.random().toString(36).slice(2,7)}`,
              sourceAdjustmentId: sourceId, source: "wall-adjustment", floorId: floor?.id || "", roomId: room?.id || "",
              itemType: kind, customType: opening.label || opening.kind, label: opening.label || opening.kind,
              length: Number(opening.length || opening.w || 0), height: Number(opening.height || opening.h || 0), qty: Number(opening.count || 1),
              finishType: kind === "Window" ? "water_based" : "oil_paint", coats: 2, materialRate: 0, labourRate: 0,
              measurementSource: { roomLabel: context?.room?.roomLabel || context?.room?.type || "Room", wallLabel: context?.wallLabel || "Wall", adjustmentMode: opening.mode || "deduct" }
            };
            return { ...p, doorWindowItems: [...(p.doorWindowItems || []), item] };
          })} />
      </div>}
      {!showInterior&&<div style={{...CARD,textAlign:"center",color:C.gray,padding:"32px 16px"}}>
        <div style={{marginBottom:8}}><ProfessionalIcon name="home" size={24} /></div>
        <div style={{fontSize:13,fontWeight:700}}>Interior scope not enabled</div>
        <div style={{fontSize:11,marginTop:4}}>Go to Job Details and set scope to Interior or Both.</div>
      </div>}
    </>}

    {/* ── Exterior ── */}
    {(project.measureType||"interior")==="exterior"&&<div style={{...CARD,padding:"12px 14px"}}>
        <div style={{fontSize:13,fontWeight:800,color:C.navy,marginBottom:10}}><ProfessionalIcon name="building" size={16} /> Exterior Elevations</div>
        <ExteriorModule elevations={project.exterior||defExterior()} onChange={v=>up(p=>({...p,exterior:v}))} config={project.exteriorConfig||defExteriorConfig()} onConfigChange={v=>up(p=>({...p,exteriorConfig:v}))} quoteMode={project.quoteMode} paintingType={project.projectType || "fresh"}/>
      </div>}

    {/* ── Wood, Metal & Joinery (unified shell over Door & Window + Polish/Enamel) ── */}
    {(()=>{
      const rawMT = project.measureType || "interior";
      const isJoinery = rawMT==="joinery" || rawMT==="polish" || rawMT==="doorwindow";
      if (!isJoinery) return null;
      return <div style={CARD}>
        <JoineryModule
          doorWindowItems={project.doorWindowItems||[]} onDoorWindowChange={v=>up(p=>({...p,doorWindowItems:v}))}
          polishItems={project.polishItems||[]} onPolishChange={v=>up(p=>({...p,polishItems:v}))}
          doorWindowTotal={doorWindowCalc.total} polishTotal={polishCalc.total}
          floors={project.floors||[]}
        />
      </div>;
    })()}

    {/* ── Wallpaper ── */}
    {(project.measureType||"interior")==="wallpaper"&&<div style={{...CARD,padding:"12px 14px"}}>
      <WallpaperMeasurementTab items={project.wallpaperItems||[]} onChange={v=>up(p=>({...p,wallpaperItems:v}))}/>
    </div>}

    {/* ── Texture ── */}
    {(project.measureType||"interior")==="texture"&&<div style={{...CARD,padding:"12px 14px"}}>
      <TextureMeasurementTab items={project.TX2_textureItems||[]} onChange={v=>up(p=>({...p,TX2_textureItems:v}))}/>
    </div>}

    {/* ── Waterproofing ── */}
    {(project.measureType||"interior")==="waterproofing"&&<div style={{...CARD,padding:"12px 14px"}}>
      <WaterproofingMeasurementTab items={project.waterproofingItems||[]} onChange={v=>up(p=>{const wpEvidence=(v||[]).flatMap(it=>(it.evidencePhotos||[]).map(ph=>({...ph,source:"waterproofing",waterproofingType:it.waterproofType,waterproofingLabel:it.label||it.customTypeName||it.waterproofType})));const keep=(p.siteProofPhotos||[]).filter(ph=>ph?.source!=="waterproofing");return {...p,waterproofingItems:v,siteProofPhotos:[...keep,...wpEvidence]};})} paintingType={project.projectType||"fresh"}/>
    </div>}
  </>;
}
