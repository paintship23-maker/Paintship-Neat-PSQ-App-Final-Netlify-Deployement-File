import React from "react";
import ProfessionalIcon from "./ProfessionalIcon.jsx";
const ALIASES = {
  "🏢":"apartment", "🏘":"building", "🏬":"retail", "🏭":"industrial", "📍":"floor",
  "🎨":"paintFinish", "🏆":"estimate", "💎":"material", "✍️":"accepted", "👤":"client",
  "🧑":"client", "👥":"users", "🗂":"job", "📁":"job", "📄":"estimate",
  "🧾":"estimate", "🧱":"wall", "🏔":"texture", "🔍":"condition", "🏠":"home",
  "🏗":"building", "🏡":"home", "🔑":"rental", "🛍":"retail", "📌":"pin",
  "📐":"ruler", "🧪":"condition", "🧑‍💼":"client", "🌿":"leaf", "👑":"crown",
  "✨":"sparkles", "🛠️":"tool", "🛠":"tool", "🧹":"brush", "🪣":"bucket",
  "🧴":"bottle", "🛢":"droplet", "🛢️":"droplet", "💅":"sparkles", "🖼":"image",
  "🛡":"shield", "🛡️":"shield", "✅":"check", "⚠️":"warning", "⚠":"warning",
  "🚨":"warning", "💧":"droplet", "🟤":"layers", "🟢":"check", "🌧️":"droplet",
  "💼":"briefcase", "🚪":"door", "🪟":"window", "🛤":"layers", "🔠":"clipboard",
  "⬜":"layers", "⬛":"building", "⬆":"plus", "✏️":"paint", "✏":"paint",
  "🔧":"wrench", "🏚":"home", "🔲":"layers", "🔄":"layers", "🛒":"cart",
  "📋":"clipboard", "🧰":"tool", "🏷️":"clipboard", "▦":"layers", "▤":"clipboard",
  "◈":"leaf", "◆":"gem", "♛":"crown", "✦":"sparkles", "⚙":"settings",
  "◉":"paint", "🔩":"wrench", "📜":"clipboard", "📏":"ruler"
};
export default function IconToken({value, size=16, color="currentColor", style={}}) {
  if (!value) return null;
  const name = ALIASES[value] || value;
  const valid = new Set(["home","building","door","image","layers","shield","lock","paint","ruler","clipboard","cart","plus","logout","leaf","gem","crown","sparkles","tool","brush","bucket","bottle","droplet","check","warning","wrench","house","truck","briefcase","calendar","users","pin","window","wall","money","settings","client","job","estimate","texture","material","accepted","floor","finish","paintFinish","waterproofing","freshPaint","repaint","quotation","hardware","condition","scope","apartment","retail","industrial","rental","wallCondition","userCheck"]);
  if (valid.has(name)) return <ProfessionalIcon name={name} size={size} color={color} style={style}/>;
  return <ProfessionalIcon name="layers" size={size} color={color} style={style}/>;
}
