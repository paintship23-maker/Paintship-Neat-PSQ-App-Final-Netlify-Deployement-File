// ─── Modular Master Rates: finish pricing master data & persistence ───────
// Centralized per-sq.ft. rate definitions for every finish category and tier.
// Rates are persisted in localStorage so they can be updated dynamically and
// survive page reloads. Use `getRateForFinish(category, tierId, subCategory, paintingType)`
// for lookups in calculation code; it returns the active (possibly overridden) rate.

// ── Types ───────────────────────────────────────────────────────────────────

export type FinishBase = "water" | "oil" | "none";
export type PaintingType = "fresh" | "repaint";

export type FinishTier = {
  /** true for user-added finishes created via "+ Add Custom Finish" */
  isCustom?: boolean;
  id: string;
  label: string;
  base: FinishBase;
  /** default per-sq.ft. rate (₹) */
  r: number;
};

export type FinishCategoryKey =
  | "interior"
  | "exterior"
  | "woodMetal"
  | "texture"
  | "wallpaper";

export type FinishSubCategoryKey =
  | "putty"
  | "primer"
  | "paint"
  | "topcoat"
  | "oilPaint"
  | "polish"
  | "texture"
  | "protection"
  | "wallpaper";

export type FinishCategory = {
  key: FinishCategoryKey;
  label: string;
  icon: string;
  /** sub-finish groups under this category */
  subCategories: {
    key: FinishSubCategoryKey;
    label: string;
    icon: string;
    tiers: FinishTier[];
  }[];
};

export type MasterRatesState = {
  fresh: FinishCategory[];
  repaint: FinishCategory[];
};

// ── Default master rate data (FRESH) ────────────────────────────────────────

const INTERIOR_FRESH: FinishCategory = {
  key: "interior",
  label: "Interior",
  icon: "🏠",
  subCategories: [
    {
      key: "putty",
      label: "Wall Putty",
      icon: "🪣",
      tiers: [
        { id: "white_cement", label: "White Cement Putty", base: "none", r: 8 },
        { id: "wall_putty", label: "Wall Putty", base: "none", r: 10 },
        { id: "acrylic_putty", label: "Acrylic Putty", base: "none", r: 14 },
        { id: "polymer", label: "Polymer Putty", base: "none", r: 15 },
        { id: "waterproof", label: "Waterproof Putty", base: "none", r: 20 },
      ],
    },
    {
      key: "primer",
      label: "Primer",
      icon: "🧴",
      tiers: [
        { id: "interior", label: "Interior Primer", base: "water", r: 7 },
        { id: "acrylic_p", label: "Acrylic Primer", base: "water", r: 8 },
        { id: "wood", label: "Wood Primer", base: "oil", r: 11 },
        { id: "metal", label: "Metal Primer", base: "oil", r: 12 },
      ],
    },
    {
      key: "paint",
      label: "Wall Paint",
      icon: "🎨",
      tiers: [
        { id: "distemper", label: "Distemper", base: "water", r: 10 },
        { id: "economy_emulsion", label: "Economy Emulsion", base: "water", r: 18 },
        { id: "premium_emulsion", label: "Premium Emulsion", base: "water", r: 32 },
        { id: "luxury_emulsion", label: "Luxury Emulsion", base: "water", r: 45 },
        { id: "designer_finish", label: "Designer Finish", base: "water", r: 60 },
        { id: "anti_fungal", label: "Anti-Fungal Paint", base: "water", r: 28 },
        { id: "washable", label: "Washable Paint", base: "water", r: 25 },
        { id: "synthetic_enamel", label: "Synthetic Enamel", base: "oil", r: 25 },
        { id: "high_gloss", label: "High Gloss Enamel", base: "oil", r: 30 },
      ],
    },
    {
      key: "topcoat",
      label: "Topcoat",
      icon: "✨",
      tiers: [
        { id: "clear_varnish", label: "Clear Varnish", base: "none", r: 12 },
        { id: "polyurethane", label: "Polyurethane", base: "none", r: 18 },
      ],
    },
  ],
};

const EXTERIOR_FRESH: FinishCategory = {
  key: "exterior",
  label: "Exterior",
  icon: "🏗",
  subCategories: [
    {
      key: "putty",
      label: "Putty",
      icon: "🪣",
      tiers: [
        { id: "white_cement_ext", label: "White Cement", base: "none", r: 8 },
        { id: "exterior_putty", label: "Exterior Putty", base: "none", r: 12 },
      ],
    },
    {
      key: "primer",
      label: "Primer",
      icon: "🧴",
      tiers: [
        { id: "exterior_primer", label: "Exterior Primer", base: "water", r: 9 },
        { id: "alkali_primer", label: "Alkali Resistant Primer", base: "water", r: 11 },
      ],
    },
    {
      key: "paint",
      label: "Exterior Paint",
      icon: "🎨",
      tiers: [
        { id: "economy_ext", label: "Economy Exterior Emulsion", base: "water", r: 20 },
        { id: "premium_ext", label: "Premium Exterior Emulsion", base: "water", r: 32 },
        { id: "luxury_ext", label: "Luxury Exterior Emulsion", base: "water", r: 50 },
        { id: "ultra_luxury_ext", label: "Ultra Luxury Exterior Emulsion", base: "water", r: 75 },
      ],
    },
    {
      key: "protection",
      label: "Protection Coating",
      icon: "🛡",
      tiers: [
        { id: "waterproof", label: "Waterproof Coating", base: "none", r: 18 },
        { id: "elastomeric", label: "Elastomeric Coating", base: "none", r: 25 },
        { id: "anti_fungal_ext", label: "Anti-Fungal Coating", base: "none", r: 20 },
        { id: "crack_sealant", label: "Crack Filler / Joint Sealant", base: "none", r: 22 },
        { id: "integral_waterproofing", label: "Integral Waterproofing Compound", base: "none", r: 16 },
        { id: "terrace_membrane", label: "Terrace Membrane System", base: "none", r: 45 },
      ],
    },
    {
      key: "texture",
      label: "Decorative Finish",
      icon: "🏔",
      tiers: [
        { id: "exterior_texture", label: "Exterior Texture", base: "none", r: 35 },
        { id: "stone_finish", label: "Stone Finish", base: "none", r: 55 },
        { id: "sand_texture", label: "Sand Texture", base: "none", r: 28 },
      ],
    },
  ],
};

const WOOD_METAL_FRESH: FinishCategory = {
  key: "woodMetal",
  label: "Wood & Metal",
  icon: "🚪",
  subCategories: [
    {
      key: "oilPaint",
      label: "Enamel / Trim",
      icon: "🛢",
      tiers: [
        { id: "synthetic_enamel", label: "Synthetic Enamel", base: "oil", r: 25 },
        { id: "high_gloss", label: "High Gloss", base: "oil", r: 30 },
        { id: "oil_paint", label: "Oil Paint", base: "oil", r: 28 },
        { id: "duco_finish", label: "Duco Finish", base: "oil", r: 55 },
      ],
    },
    {
      key: "polish",
      label: "Polish",
      icon: "💅",
      tiers: [
        { id: "melamine", label: "Melamine Polish", base: "none", r: 35 },
        { id: "pu", label: "PU Polish", base: "none", r: 45 },
        { id: "nc", label: "NC Polish", base: "none", r: 28 },
        { id: "french", label: "French Polish", base: "none", r: 50 },
        { id: "wood_stain", label: "Wood Stain", base: "none", r: 20 },
      ],
    },
    {
      key: "topcoat",
      label: "Topcoat",
      icon: "✨",
      tiers: [
        { id: "clear_varnish", label: "Clear Varnish", base: "none", r: 12 },
        { id: "polyurethane", label: "Polyurethane", base: "none", r: 18 },
      ],
    },
  ],
};

const TEXTURE_FRESH: FinishCategory = {
  key: "texture",
  label: "Texture",
  icon: "🧱",
  subCategories: [
    {
      key: "texture",
      label: "Texture",
      icon: "🏔",
      tiers: [
        { id: "roller", label: "Roller Texture", base: "none", r: 22 },
        { id: "metallic", label: "Metallic Finish", base: "none", r: 50 },
        { id: "venetian", label: "Venetian Finish", base: "none", r: 70 },
        { id: "stucco", label: "Stucco Finish", base: "none", r: 35 },
      ],
    },
  ],
};

const WALLPAPER_FRESH: FinishCategory = {
  key: "wallpaper",
  label: "Wallpaper",
  icon: "🖼",
  subCategories: [
    {
      key: "wallpaper",
      label: "Wallpaper",
      icon: "🖼",
      tiers: [
        { id: "vinyl", label: "Vinyl Wallpaper", base: "none", r: 40 },
        { id: "non_woven", label: "Non-Woven Wallpaper", base: "none", r: 55 },
        { id: "fabric", label: "Fabric Wallpaper", base: "none", r: 80 },
      ],
    },
  ],
};

export const DEFAULT_MASTER_RATES_FRESH: FinishCategory[] = [
  INTERIOR_FRESH,
  EXTERIOR_FRESH,
  WOOD_METAL_FRESH,
  TEXTURE_FRESH,
  WALLPAPER_FRESH,
];

// ── Default master rate data (REPAINT) ──

const INTERIOR_REPAINT: FinishCategory = {
  key: "interior",
  label: "Interior",
  icon: "🏠",
  subCategories: [
    {
      key: "putty",
      label: "Wall Putty",
      icon: "🪣",
      tiers: [
        { id: "white_cement", label: "White Cement Putty", base: "none", r: 6 },
        { id: "wall_putty", label: "Wall Putty", base: "none", r: 8 },
        { id: "acrylic_putty", label: "Acrylic Putty", base: "none", r: 11 },
        { id: "polymer", label: "Polymer Putty", base: "none", r: 12 },
        { id: "waterproof", label: "Waterproof Putty", base: "none", r: 15 },
      ],
    },
    {
      key: "primer",
      label: "Primer",
      icon: "🧴",
      tiers: [
        { id: "interior", label: "Interior Primer", base: "water", r: 5 },
        { id: "acrylic_p", label: "Acrylic Primer", base: "water", r: 6 },
        { id: "wood", label: "Wood Primer", base: "oil", r: 8 },
        { id: "metal", label: "Metal Primer", base: "oil", r: 9 },
      ],
    },
    {
      key: "paint",
      label: "Wall Paint",
      icon: "🎨",
      tiers: [
        { id: "distemper", label: "Distemper", base: "water", r: 8 },
        { id: "economy_emulsion", label: "Economy Emulsion", base: "water", r: 14 },
        { id: "premium_emulsion", label: "Premium Emulsion", base: "water", r: 24 },
        { id: "luxury_emulsion", label: "Luxury Emulsion", base: "water", r: 34 },
        { id: "designer_finish", label: "Designer Finish", base: "water", r: 45 },
        { id: "anti_fungal", label: "Anti-Fungal Paint", base: "water", r: 21 },
        { id: "washable", label: "Washable Paint", base: "water", r: 19 },
        { id: "synthetic_enamel", label: "Synthetic Enamel", base: "oil", r: 19 },
        { id: "high_gloss", label: "High Gloss Enamel", base: "oil", r: 23 },
      ],
    },
    {
      key: "topcoat",
      label: "Topcoat",
      icon: "✨",
      tiers: [
        { id: "clear_varnish", label: "Clear Varnish", base: "none", r: 9 },
        { id: "polyurethane", label: "Polyurethane", base: "none", r: 14 },
      ],
    },
  ],
};

const EXTERIOR_REPAINT: FinishCategory = {
  key: "exterior",
  label: "Exterior",
  icon: "🏗",
  subCategories: [
    {
      key: "putty",
      label: "Putty",
      icon: "🪣",
      tiers: [
        { id: "white_cement_ext", label: "White Cement", base: "none", r: 6 },
        { id: "exterior_putty", label: "Exterior Putty", base: "none", r: 9 },
      ],
    },
    {
      key: "primer",
      label: "Primer",
      icon: "🧴",
      tiers: [
        { id: "exterior_primer", label: "Exterior Primer", base: "water", r: 7 },
        { id: "alkali_primer", label: "Alkali Resistant Primer", base: "water", r: 8 },
      ],
    },
    {
      key: "paint",
      label: "Exterior Paint",
      icon: "🎨",
      tiers: [
        { id: "economy_ext", label: "Economy Exterior Emulsion", base: "water", r: 15 },
        { id: "premium_ext", label: "Premium Exterior Emulsion", base: "water", r: 24 },
        { id: "luxury_ext", label: "Luxury Exterior Emulsion", base: "water", r: 38 },
        { id: "ultra_luxury_ext", label: "Ultra Luxury Exterior Emulsion", base: "water", r: 56 },
      ],
    },
    {
      key: "protection",
      label: "Protection Coating",
      icon: "🛡",
      tiers: [
        { id: "waterproof", label: "Waterproof Coating", base: "none", r: 14 },
        { id: "elastomeric", label: "Elastomeric Coating", base: "none", r: 19 },
        { id: "anti_fungal_ext", label: "Anti-Fungal Coating", base: "none", r: 15 },
        { id: "crack_sealant", label: "Crack Filler / Joint Sealant", base: "none", r: 18 },
        { id: "integral_waterproofing", label: "Integral Waterproofing Compound", base: "none", r: 13 },
        { id: "terrace_membrane", label: "Terrace Membrane System", base: "none", r: 36 },
      ],
    },
    {
      key: "texture",
      label: "Decorative Finish",
      icon: "🏔",
      tiers: [
        { id: "exterior_texture", label: "Exterior Texture", base: "none", r: 26 },
        { id: "stone_finish", label: "Stone Finish", base: "none", r: 41 },
        { id: "sand_texture", label: "Sand Texture", base: "none", r: 21 },
      ],
    },
  ],
};

const WOOD_METAL_REPAINT: FinishCategory = {
  key: "woodMetal",
  label: "Wood & Metal",
  icon: "🚪",
  subCategories: [
    {
      key: "oilPaint",
      label: "Enamel / Trim",
      icon: "🛢",
      tiers: [
        { id: "synthetic_enamel", label: "Synthetic Enamel", base: "oil", r: 19 },
        { id: "high_gloss", label: "High Gloss", base: "oil", r: 23 },
        { id: "oil_paint", label: "Oil Paint", base: "oil", r: 21 },
        { id: "duco_finish", label: "Duco Finish", base: "oil", r: 41 },
      ],
    },
    {
      key: "polish",
      label: "Polish",
      icon: "💅",
      tiers: [
        { id: "melamine", label: "Melamine Polish", base: "none", r: 26 },
        { id: "pu", label: "PU Polish", base: "none", r: 34 },
        { id: "nc", label: "NC Polish", base: "none", r: 21 },
        { id: "french", label: "French Polish", base: "none", r: 38 },
        { id: "wood_stain", label: "Wood Stain", base: "none", r: 15 },
      ],
    },
    {
      key: "topcoat",
      label: "Topcoat",
      icon: "✨",
      tiers: [
        { id: "clear_varnish", label: "Clear Varnish", base: "none", r: 9 },
        { id: "polyurethane", label: "Polyurethane", base: "none", r: 14 },
      ],
    },
  ],
};

const TEXTURE_REPAINT: FinishCategory = {
  key: "texture",
  label: "Texture",
  icon: "🧱",
  subCategories: [
    {
      key: "texture",
      label: "Texture",
      icon: "🏔",
      tiers: [
        { id: "roller", label: "Roller Texture", base: "none", r: 17 },
        { id: "metallic", label: "Metallic Finish", base: "none", r: 38 },
        { id: "venetian", label: "Venetian Finish", base: "none", r: 53 },
        { id: "stucco", label: "Stucco Finish", base: "none", r: 26 },
      ],
    },
  ],
};

const WALLPAPER_REPAINT: FinishCategory = {
  key: "wallpaper",
  label: "Wallpaper",
  icon: "🖼",
  subCategories: [
    {
      key: "wallpaper",
      label: "Wallpaper",
      icon: "🖼",
      tiers: [
        { id: "vinyl", label: "Vinyl Wallpaper", base: "none", r: 30 },
        { id: "non_woven", label: "Non-Woven Wallpaper", base: "none", r: 41 },
        { id: "fabric", label: "Fabric Wallpaper", base: "none", r: 60 },
      ],
    },
  ],
};

export const DEFAULT_MASTER_RATES_REPAINT: FinishCategory[] = [
  INTERIOR_REPAINT,
  EXTERIOR_REPAINT,
  WOOD_METAL_REPAINT,
  TEXTURE_REPAINT,
  WALLPAPER_REPAINT,
];

export const DEFAULT_MASTER_RATES = DEFAULT_MASTER_RATES_FRESH;

// ── localStorage persistence ───────────────────────────────────────────────

const STORAGE_KEY = "paintpro_master_rates_v1";

// ── Measure Only Labour Master ─────────────────────────────────────────────
// Admin-controlled commercial labour pricing. Supervisors do not edit these
// values; Measure Only projects snapshot the active defaults when created.
export type MeasurementLabourPricing = {
  mode: "per_sqft" | "lump_sum";
  interiorPerSqFt: number;
  exteriorPerSqFt: number;
  interiorLumpSum: number;
  exteriorLumpSum: number;
};

export const DEFAULT_MEASUREMENT_LABOUR_PRICING: MeasurementLabourPricing = {
  mode: "per_sqft",
  interiorPerSqFt: 18,
  exteriorPerSqFt: 18,
  interiorLumpSum: 0,
  exteriorLumpSum: 0,
};

const MEASUREMENT_LABOUR_KEY = "paintpro_measurement_labour_master_v1";

export function getMeasurementLabourPricing(): MeasurementLabourPricing {
  try {
    const raw = localStorage.getItem(MEASUREMENT_LABOUR_KEY);
    if (!raw) return { ...DEFAULT_MEASUREMENT_LABOUR_PRICING };
    const parsed = JSON.parse(raw);
    return {
      mode: parsed?.mode === "lump_sum" ? "lump_sum" : "per_sqft",
      interiorPerSqFt: Math.max(0, Number(parsed?.interiorPerSqFt ?? DEFAULT_MEASUREMENT_LABOUR_PRICING.interiorPerSqFt) || 0),
      exteriorPerSqFt: Math.max(0, Number(parsed?.exteriorPerSqFt ?? DEFAULT_MEASUREMENT_LABOUR_PRICING.exteriorPerSqFt) || 0),
      interiorLumpSum: Math.max(0, Number(parsed?.interiorLumpSum ?? 0) || 0),
      exteriorLumpSum: Math.max(0, Number(parsed?.exteriorLumpSum ?? 0) || 0),
    };
  } catch {
    return { ...DEFAULT_MEASUREMENT_LABOUR_PRICING };
  }
}

export function saveMeasurementLabourPricing(pricing: MeasurementLabourPricing): boolean {
  try {
    localStorage.setItem(MEASUREMENT_LABOUR_KEY, JSON.stringify({
      mode: pricing.mode === "lump_sum" ? "lump_sum" : "per_sqft",
      interiorPerSqFt: Math.max(0, Number(pricing.interiorPerSqFt) || 0),
      exteriorPerSqFt: Math.max(0, Number(pricing.exteriorPerSqFt) || 0),
      interiorLumpSum: Math.max(0, Number(pricing.interiorLumpSum) || 0),
      exteriorLumpSum: Math.max(0, Number(pricing.exteriorLumpSum) || 0),
    }));
    return true;
  } catch { return false; }
}

export function resetMeasurementLabourPricing(): MeasurementLabourPricing {
  try { localStorage.removeItem(MEASUREMENT_LABOUR_KEY); } catch { /* ignore */ }
  return { ...DEFAULT_MEASUREMENT_LABOUR_PRICING };
}

function isLegacyCustomPlaceholder(t: FinishTier): boolean {
  return t.id === "custom";
}

function cleanCategories(categories: FinishCategory[]): { cleaned: FinishCategory[]; purged: boolean } {
  let purged = false;
  const cleaned = (categories || []).map((cat) => ({
    ...cat,
    subCategories: (cat.subCategories || []).map((sub) => {
      const tiers = (sub.tiers || []).filter((t) => {
        if (isLegacyCustomPlaceholder(t)) {
          purged = true;
          return false;
        }
        return true;
      });
      return { ...sub, tiers };
    }),
  }));
  return { cleaned, purged };
}

export function getStoredMasterRates(): MasterRatesState {
  const defaultState: MasterRatesState = {
    fresh: DEFAULT_MASTER_RATES_FRESH,
    repaint: DEFAULT_MASTER_RATES_REPAINT,
  };

  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return defaultState;
    const parsed = JSON.parse(raw);

    // Migration logic for old schema (where saved item was FinishCategory[])
    if (Array.isArray(parsed) && parsed.length > 0) {
      const { cleaned, purged } = cleanCategories(parsed);
      const state: MasterRatesState = {
        fresh: cleaned,
        repaint: DEFAULT_MASTER_RATES_REPAINT,
      };
      saveMasterRates(state);
      return state;
    }

    if (parsed && typeof parsed === "object" && (parsed.fresh || parsed.repaint)) {
      const freshRes = cleanCategories(Array.isArray(parsed.fresh) && parsed.fresh.length > 0 ? parsed.fresh : DEFAULT_MASTER_RATES_FRESH);
      const repaintRes = cleanCategories(Array.isArray(parsed.repaint) && parsed.repaint.length > 0 ? parsed.repaint : DEFAULT_MASTER_RATES_REPAINT);

      const state: MasterRatesState = {
        fresh: freshRes.cleaned,
        repaint: repaintRes.cleaned,
      };

      if (freshRes.purged || repaintRes.purged) {
        saveMasterRates(state);
      }
      return state;
    }

    return defaultState;
  } catch {
    return defaultState;
  }
}

export function saveMasterRates(rates: MasterRatesState): boolean {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(rates));
    return true;
  } catch {
    return false;
  }
}

export function resetMasterRates(): MasterRatesState {
  try {
    localStorage.removeItem(STORAGE_KEY);
  } catch {
    /* ignore */
  }
  return {
    fresh: DEFAULT_MASTER_RATES_FRESH,
    repaint: DEFAULT_MASTER_RATES_REPAINT,
  };
}



// ── Package Budget Master (V12) ─────────────────────────────────────────────
// Package pricing is the single source of truth for standard quotation,
// measurement totals and invoice/PDF totals.  Four package stacks are stored
// independently for Interior/Exterior and Fresh/Repainting.
export type PaintFinish = "matte" | "sheen" | "high_shine";
export type PackageSurface = "interior" | "exterior";
export type PackageComponent = {
  id?: string;
  enabled: boolean;
  category: "surfacePrep" | "putty" | "primer" | "paint";
  typeId: string;
  label: string;
  brand: string;
  product: string;
  rate: number;
  coats: number;
  finishRates?: Partial<Record<PaintFinish, number>>;
  allowedTypes?: string[];
};
export type PackageBudget = {
  id: "economy" | "premium" | "luxury" | "ultra_luxury" | "custom";
  label: string;
  paintFinish: PaintFinish;
  components: PackageComponent[];
};

type PackageSet = Record<string, PackageBudget>;

const PF = (rate:number, delta=1) => ({ matte:rate, sheen:rate+delta, high_shine:rate+delta*2 });
const make = (id:any,label:string,prep:any,putty:any,primer:any,paint:any,finishRates:any, allowed:string[], paintLabel:string, surface:PackageSurface):PackageBudget => ({
  id,label,paintFinish:id==="economy"?"matte":id==="ultra_luxury"?"high_shine":"sheen",
  components:[
    ...(prep&&prep.length? [{enabled:!!prep[4],category:"surfacePrep",typeId:prep[0],label:prep[1],brand:prep[2]||"",product:prep[1],rate:Number(prep[3])||0,coats:1}] : []),
    {enabled:true,category:"putty",typeId:putty[0],label:putty[1],brand:"Standard",product:putty[1],rate:putty[2],coats:1},
    {enabled:true,category:"primer",typeId:primer[0],label:primer[1],brand:"Standard",product:primer[1],rate:primer[2],coats:1},
    {enabled:true,category:"paint",typeId:paint[0],label:paintLabel,brand:"Standard",product:paintLabel,rate:paint[1],coats:2,finishRates,allowedTypes:allowed},
  ]
});

const INTERIOR_FRESH_PACKAGES:PackageSet = {
  economy:make("economy","Economy",[],["white_cement","White Cement Putty",8],["interior","Interior Primer",7],["economy_emulsion",18],PF(18),["distemper","economy_emulsion"],"Economy Emulsion","interior"),
  premium:make("premium","Premium",[],["wall_putty","Wall Putty",10],["acrylic_p","Acrylic Primer",8],["premium_emulsion",32],PF(32),["premium_emulsion","washable","anti_fungal"],"Premium Emulsion","interior"),
  luxury:make("luxury","Luxury",[],["acrylic_putty","Acrylic Putty",14],["acrylic_p","Acrylic Primer",8],["luxury_emulsion",45],PF(45),["luxury_emulsion","designer_finish","washable","anti_fungal"],"Luxury Emulsion","interior"),
  ultra_luxury:make("ultra_luxury","Ultra Luxury",[],["polymer","Polymer Putty",15],["acrylic_p","Acrylic Primer",8],["designer_finish",60],PF(60),["designer_finish","luxury_emulsion","high_gloss"],"Designer Finish","interior"),
};
const INTERIOR_REPAINT_PACKAGES:PackageSet = {
  economy:make("economy","Economy",["surface_prep","Surface Preparation","",0,false],["white_cement","White Cement Putty",6],["interior","Interior Primer",5],["economy_emulsion",14],PF(14),["distemper","economy_emulsion"],"Economy Emulsion","interior"),
  premium:make("premium","Premium",["surface_prep","Surface Preparation","",0,false],["wall_putty","Wall Putty",8],["acrylic_p","Acrylic Primer",6],["premium_emulsion",24],PF(24),["premium_emulsion","washable","anti_fungal"],"Premium Emulsion","interior"),
  luxury:make("luxury","Luxury",["surface_prep","Surface Preparation","",0,false],["acrylic_putty","Acrylic Putty",11],["acrylic_p","Acrylic Primer",6],["luxury_emulsion",34],PF(34),["luxury_emulsion","designer_finish","washable","anti_fungal"],"Luxury Emulsion","interior"),
  ultra_luxury:make("ultra_luxury","Ultra Luxury",["surface_prep","Surface Preparation","",0,false],["polymer","Polymer Putty",12],["acrylic_p","Acrylic Primer",6],["designer_finish",45],PF(45),["designer_finish","luxury_emulsion","high_gloss"],"Designer Finish","interior"),
};
const EXTERIOR_FRESH_PACKAGES:PackageSet = {
  economy:make("economy","Economy",[],["white_cement_ext","White Cement",8],["exterior_primer","Exterior Primer",9],["economy_ext",20],PF(20),["economy_ext"],"Economy Exterior Emulsion","exterior"),
  premium:make("premium","Premium",[],["exterior_putty","Exterior Putty",12],["exterior_primer","Exterior Primer",9],["premium_ext",32],PF(32),["premium_ext"],"Premium Exterior Emulsion","exterior"),
  luxury:make("luxury","Luxury",[],["exterior_putty","Exterior Putty",12],["alkali_primer","Alkali Resistant Primer",11],["luxury_ext",50],PF(50),["luxury_ext"],"Luxury Exterior Emulsion","exterior"),
  ultra_luxury:make("ultra_luxury","Ultra Luxury",[],["exterior_putty","Exterior Putty",12],["alkali_primer","Alkali Resistant Primer",11],["ultra_luxury_ext",75],PF(75),["ultra_luxury_ext"],"Ultra Luxury Exterior Emulsion","exterior"),
};
const EXTERIOR_REPAINT_PACKAGES:PackageSet = {
  economy:make("economy","Economy",["surface_prep","Surface Preparation","",0,false],["white_cement_ext","White Cement",6],["exterior_primer","Exterior Primer",7],["economy_ext",15],PF(15),["economy_ext"],"Economy Exterior Emulsion","exterior"),
  premium:make("premium","Premium",["surface_prep","Surface Preparation","",0,false],["exterior_putty","Exterior Putty",9],["exterior_primer","Exterior Primer",7],["premium_ext",24],PF(24),["premium_ext"],"Premium Exterior Emulsion","exterior"),
  luxury:make("luxury","Luxury",["surface_prep","Surface Preparation","",0,false],["exterior_putty","Exterior Putty",9],["alkali_primer","Alkali Resistant Primer",8],["luxury_ext",38],PF(38),["luxury_ext"],"Luxury Exterior Emulsion","exterior"),
  ultra_luxury:make("ultra_luxury","Ultra Luxury",["surface_prep","Surface Preparation","",0,false],["exterior_putty","Exterior Putty",9],["alkali_primer","Alkali Resistant Primer",8],["ultra_luxury_ext",56],PF(56),["ultra_luxury_ext"],"Ultra Luxury Exterior Emulsion","exterior"),
};

function customPackage(surface:PackageSurface):PackageBudget {
  const paintOptions=surface==="interior"?["distemper","economy_emulsion","premium_emulsion","luxury_emulsion","designer_finish","anti_fungal","washable","synthetic_enamel","high_gloss"]:["economy_ext","premium_ext","luxury_ext","ultra_luxury_ext"];
  return {id:"custom",label:"Custom",paintFinish:"matte",components:[
    {enabled:true,category:"putty",typeId:surface==="interior"?"white_cement":"exterior_putty",label:"Custom Putty",brand:"",product:"",rate:0,coats:1},
    {enabled:true,category:"primer",typeId:surface==="interior"?"interior":"exterior_primer",label:"Custom Primer",brand:"",product:"",rate:0,coats:1},
    {enabled:true,category:"paint",typeId:"custom",label:"Custom Paint",brand:"",product:"",rate:0,coats:2,finishRates:{matte:0,sheen:0,high_shine:0},allowedTypes:paintOptions}
  ]};
}
INTERIOR_FRESH_PACKAGES.custom=customPackage("interior");
INTERIOR_REPAINT_PACKAGES.custom=customPackage("interior");
EXTERIOR_FRESH_PACKAGES.custom=customPackage("exterior");
EXTERIOR_REPAINT_PACKAGES.custom=customPackage("exterior");
INTERIOR_REPAINT_PACKAGES.custom.components.unshift({enabled:false,category:"surfacePrep",typeId:"surface_prep",label:"Surface Preparation",brand:"",product:"Surface Preparation",rate:0,coats:1});
EXTERIOR_REPAINT_PACKAGES.custom.components.unshift({enabled:false,category:"surfacePrep",typeId:"surface_prep",label:"Surface Preparation",brand:"",product:"Surface Preparation",rate:0,coats:1});

const PACKAGE_DEFAULTS = {
  interiorFresh: INTERIOR_FRESH_PACKAGES,
  interiorRepaint: INTERIOR_REPAINT_PACKAGES,
  exteriorFresh: EXTERIOR_FRESH_PACKAGES,
  exteriorRepaint: EXTERIOR_REPAINT_PACKAGES,
};
const PACKAGE_STORAGE_KEY = "paintpro_package_budgets_v2";
function clonePackageDefaults(){ return JSON.parse(JSON.stringify(PACKAGE_DEFAULTS)); }
function packageKey(paintingType="fresh", surface:PackageSurface="interior"){ return `${surface}${paintingType==="repaint"?"Repaint":"Fresh"}` as keyof typeof PACKAGE_DEFAULTS; }
function stripRetiredSurfacePreparation(budgets:PackageSet, paintingType="fresh"):PackageSet {
  const out:any={...budgets};
  Object.keys(out).forEach(id=>{
    const pkg=out[id];
    if (!pkg || !Array.isArray(pkg.components)) return;
    out[id]={...pkg,components:pkg.components.filter((c:any)=>c && (c.category!=="surfacePrep" || paintingType==="repaint"))};
  });
  return out as PackageSet;
}
export function getPackageBudgets(paintingType="fresh", surface:PackageSurface="interior"):PackageSet {
  try {
    const raw=localStorage.getItem(PACKAGE_STORAGE_KEY), parsed=raw?JSON.parse(raw):null, defaults=clonePackageDefaults();
    const key=packageKey(paintingType,surface); const base=defaults[key];
    if(!parsed || typeof parsed!=="object") return stripRetiredSurfacePreparation(base, paintingType);
    const saved=parsed[key];
    if(!saved||typeof saved!=="object") return stripRetiredSurfacePreparation(base, paintingType);
    const out:any={...base};
    Object.keys(base).forEach(id=>{
      if(saved[id]) {
        const savedComponents=Array.isArray(saved[id].components)?saved[id].components:base[id].components;
        const prepDefault=(base[id].components||[]).find((c:any)=>c?.category==="surfacePrep");
        const hasPrep=savedComponents.some((c:any)=>c?.category==="surfacePrep");
        out[id]={...base[id],...saved[id],components:paintingType==="repaint"&&prepDefault&&!hasPrep?[prepDefault,...savedComponents]:savedComponents};
      }
    });
    return stripRetiredSurfacePreparation(out, paintingType);
  } catch { return stripRetiredSurfacePreparation(clonePackageDefaults()[packageKey(paintingType,surface)], paintingType); }
}
export function savePackageBudgets(budgets:PackageSet, paintingType="fresh", surface:PackageSurface="interior"):boolean {
  try { const raw=localStorage.getItem(PACKAGE_STORAGE_KEY); const all=raw?JSON.parse(raw):{}; all[packageKey(paintingType,surface)]=stripRetiredSurfacePreparation(budgets, paintingType); localStorage.setItem(PACKAGE_STORAGE_KEY,JSON.stringify(all)); return true; } catch { return false; }
}
export function resetPackageBudgets(paintingType="fresh", surface:PackageSurface="interior"){ const defaults=clonePackageDefaults(); try { const raw=localStorage.getItem(PACKAGE_STORAGE_KEY); const all=raw?JSON.parse(raw):{}; all[packageKey(paintingType,surface)]=defaults[packageKey(paintingType,surface)]; localStorage.setItem(PACKAGE_STORAGE_KEY,JSON.stringify(all)); } catch{} return defaults[packageKey(paintingType,surface)]; }
export function getPackageBudget(id:string="premium", paintingType="fresh", surface:PackageSurface="interior"){ const all=getPackageBudgets(paintingType,surface); return all[id]||all.premium; }
export function packageComponentRate(c:PackageComponent, finish:PaintFinish="matte"){ const chosen=Number(c?.finishRates?.[finish]||0); return chosen>0?chosen:Number(c?.rate||0); }
export function packageBudgetPerSqFt(id:string="premium", paintingType="fresh", surface:PackageSurface="interior"){
  const p=getPackageBudget(id,paintingType,surface); return (p.components||[]).reduce((s,c)=>s+(c.enabled?packageComponentRate(c,p.paintFinish)*Math.max(1,Number(c.coats||1)):0),0);
}
export function packageToFinishing(id:string="premium", paintingType="fresh", surface:PackageSurface="interior", paintFinishOverride?:PaintFinish){
  const p=getPackageBudget(id,paintingType,surface);
  const activeFinish:PaintFinish = paintFinishOverride || p.paintFinish || "matte";
  const isExt=surface==="exterior";
  const out:any=isExt?{
    putty:{on:false,type:"exterior_putty",customName:"",rate:0,coats:1,area:0,useRoom:true},
    primer:{on:false,type:"exterior_primer",customName:"",rate:0,coats:1,area:0,useRoom:true},
    paint:{on:false,type:"premium_ext",customName:"",rate:0,coats:2,area:0,useRoom:true}
  }:{
    putty:{on:false,type:"white_cement",customName:"",rate:0,coats:1,area:0,useRoom:true,consumption:null},
    primer:{on:false,type:"interior",customName:"",rate:0,coats:1,area:0,useRoom:true,consumption:null},
    paint:{on:false,type:"economy_emulsion",customName:"",rate:0,coats:2,area:0,useRoom:true,consumption:null}
  };
  const packageLayers=(p.components||[]).map((c,index)=>({
    id:c.id||`${c.category||"layer"}-${index}`,
    category:c.category||"paint",
    on:!!c.enabled,
    type:c.typeId||"custom",
    customName:c.label||"Custom Material",
    brand:c.brand||"",
    product:c.product||"",
    rate:packageComponentRate(c,activeFinish),
    coats:Math.max(1,Number(c.coats||1)),
    paintFinish:activeFinish,
    packageManaged:true,
    useRoom:true,
  }));
  (p.components||[]).forEach(c=>{ if(!out[c.category]) return; if(out[c.category].on) return; out[c.category]={...out[c.category],on:!!c.enabled,type:c.typeId||out[c.category].type,customName:c.label||"",rate:packageComponentRate(c,activeFinish),coats:Math.max(1,Number(c.coats||1)),brand:c.brand||"",product:c.product||"",paintFinish:activeFinish,packageManaged:true}; });
  out.packageLayers=packageLayers;
  out.packageId=id; out.paintFinish=activeFinish; out.surface=surface; out.packageManaged=true; out.paintOptions=((p.components||[]).find(c=>c.category==="paint")||{}).allowedTypes||[];
  return out;
}
export const STANDARD_PACKAGE_BRANDS=["Asian Paints","Berger Paints","Kansai Nerolac","Birla Opus","Indigo Paints","JSW Paints","Nippon Paint","Dulux","Jotun","Shalimar Paints","Sirca","ICA","Universal Paints / Uniguard","Other Brand"];

// ── Rate lookup ────────────────────────────────────────────────────────────

/**
 * Returns the active per-sq.ft. rate for a given category + tier.
 */
export function getRateForFinish(
  category: FinishCategoryKey,
  tierId: string,
  subCategory?: FinishSubCategoryKey,
  paintingType: PaintingType = "fresh"
): number {
  const masterState = getStoredMasterRates();
  const rates = masterState[paintingType] || masterState.fresh;
  const cat = rates.find((c) => c.key === category);
  if (!cat) return 0;

  for (const sub of cat.subCategories) {
    if (subCategory && sub.key !== subCategory) continue;
    const tier = sub.tiers.find((t) => t.id === tierId);
    if (tier) return tier.r;
  }

  if (!subCategory) {
    for (const sub of cat.subCategories) {
      const tier = sub.tiers.find((t) => t.id === tierId);
      if (tier) return tier.r;
    }
  }

  return 0;
}

function slugifyItemName(name: string): string {
  return (name || "")
    .toString()
    .trim()
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "_")
    .replace(/(^_|_$)/g, "") || "item";
}

/**
 * Adds a user-defined custom finish (name + base rate) to a category's
 * sub-category and returns a NEW rates array (does not mutate `rates`).
 */
export function addCustomTier(
  rates: FinishCategory[],
  categoryKey: FinishCategoryKey,
  subCategoryKey: FinishSubCategoryKey,
  name: string,
  rate: number
): FinishCategory[] {
  const trimmed = (name || "").trim();
  if (!trimmed) return rates;
  const id = `custom_${slugifyItemName(trimmed)}_${Date.now().toString(36)}`;
  const newTier: FinishTier = { id, label: trimmed, base: "none", r: Number(rate) || 0, isCustom: true };

  return rates.map((cat) => {
    if (cat.key !== categoryKey) return cat;
    return {
      ...cat,
      subCategories: cat.subCategories.map((sub) => {
        if (sub.key !== subCategoryKey) return sub;
        const idx = sub.tiers.findIndex((t) => t.id === "custom");
        const tiers =
          idx === -1
            ? [...sub.tiers, newTier]
            : [...sub.tiers.slice(0, idx), newTier, ...sub.tiers.slice(idx)];
        return { ...sub, tiers };
      }),
    };
  });
}

/**
 * Removes a previously-added custom tier by id. Refuses to remove built-in
 * (non-custom) tiers. Returns a NEW rates array.
 */
export function removeCustomTier(
  rates: FinishCategory[],
  categoryKey: FinishCategoryKey,
  subCategoryKey: FinishSubCategoryKey,
  tierId: string
): FinishCategory[] {
  return rates.map((cat) => {
    if (cat.key !== categoryKey) return cat;
    return {
      ...cat,
      subCategories: cat.subCategories.map((sub) => {
        if (sub.key !== subCategoryKey) return sub;
        return {
          ...sub,
          tiers: sub.tiers.filter((t) => !(t.id === tierId && t.isCustom)),
        };
      }),
    };
  });
}

/**
 * Returns the full FinishTier object for a given category + tier id.
 */
export function getTierForFinish(
  category: FinishCategoryKey,
  tierId: string,
  subCategory?: FinishSubCategoryKey,
  paintingType: PaintingType = "fresh"
): FinishTier | null {
  const masterState = getStoredMasterRates();
  const rates = masterState[paintingType] || masterState.fresh;
  const cat = rates.find((c) => c.key === category);
  if (!cat) return null;

  for (const sub of cat.subCategories) {
    if (subCategory && sub.key !== subCategory) continue;
    const tier = sub.tiers.find((t) => t.id === tierId);
    if (tier) return tier;
  }

  if (!subCategory) {
    for (const sub of cat.subCategories) {
      const tier = sub.tiers.find((t) => t.id === tierId);
      if (tier) return tier;
    }
  }

  return null;
}


// ── Brand / product / package-specific rate catalog (V19) ──────────────────
// Prices are admin-entered. Seed product names are suggestions, not market-price claims.
export type BrandProductRate = {
  id: string; surface: "interior" | "exterior"; paintingType: "fresh" | "repaint";
  packageId: "economy" | "premium" | "luxury" | "ultra_luxury" | "custom";
  brand: string; category: "putty" | "primer" | "paint" | "enamel" | "polish" | "waterproofing";
  product: string; materialType: string; rate: number;
  finishRates?: Partial<Record<PaintFinish, number>>; finish?: string; unit?: string;
};
const BRAND_PRODUCT_STORAGE_KEY = "paintship_brand_product_rates_v1";
const CATALOG_SURFACE_OVERRIDES: Record<string, string> = {
  // Asian Paints — explicit exterior families
  "Apex Exterior Emulsion":"exterior","Apex Advanced Dust Proof":"exterior","Apex Ultima":"exterior","Apex Ultima Protek":"exterior","Apex Ultima Protek Duralife":"exterior","Apex Ultima Stretch":"exterior","Apex Ultima Suprema":"exterior","Ace Exterior Emulsion":"exterior","Ace Advanced":"exterior","Ace Shyne":"exterior","TruCare Exterior Wall Primer":"exterior","TruCare Exterior Wall Primer Advanced":"exterior","TruCare Exterior Wall Putty":"exterior","Apex Tile Guard":"exterior","Apex Floor Guard":"exterior",
  // Berger Paints
  "WeatherCoat Long Life":"exterior","WeatherCoat Anti Dust":"exterior","WeatherCoat All Guard":"exterior","WeatherCoat Smooth":"exterior","WeatherCoat Glow":"exterior","WeatherCoat Tile Protect":"exterior","Weathercoat Anti Dustt":"exterior","Weathercoat Anti Dustt Kool":"exterior","Weathercoat Glow":"exterior","Weathercoat Champ":"exterior","WeatherCoat Exterior Primer":"exterior","HomeShield Dampstop":"exterior",
  // Kansai Nerolac exterior Excel family
  "Excel Total Floor Coat":"exterior","Excel Total":"exterior","Suraksha Plus":"exterior","Suraksha Plus NXT":"exterior","Suraksha Acrylic Exterior Emulsion":"exterior","Neu Latex Exterior":"exterior","Excel Mica Marble":"exterior","Excel Top Guard":"exterior","Excel Anti-Peel":"exterior","Excel Everlast":"exterior","Excel Total Putty":"exterior","Excel Alkali Primer":"exterior","Kansai Nerolac|Exterior Primer":"exterior","Nippon Paint|Exterior Primer":"exterior",
  // Birla Opus — exterior is intentionally limited to products explicitly sold as exterior
  "One True Look":"exterior","Calista Neo Star":"exterior","Style Power Bright":"exterior","Style Perfect Start Primer":"exterior","Style Exterior Emulsion":"exterior","Birla Opus|Exterior Wall Primer":"exterior",
  // Indigo Paints
  "Indigo Paints|Exterior Emulsion":"exterior","Indigo Paints|Exterior Wall Putty":"exterior","Dirtproof & Waterproof Exterior Emulsion":"exterior","Dirtproof & Waterproof Exterior Laminate":"exterior",
  // JSW Paints
  "Elegant Exteriors":"exterior","Regal Exteriors":"exterior","Majestic Exteriors":"exterior","Pixa Ultima":"exterior","Pixa Excel":"exterior","Pixa Advanced":"exterior","Pixa Exterior Emulsion":"exterior","Wall Primer Exteriors":"exterior","Profect Wall Primer Eco Exteriors":"exterior",
  // Nippon Paint
  "Weatherbond Pro":"exterior","Weatherbond Advance":"exterior","Weatherbond 8":"exterior","Weatherbond":"exterior","Weatherbond Solareflect":"exterior","Suno Xtra Dust Shield":"exterior","Q-Shield":"exterior","DuraFresh Solo":"exterior","Shogun Ultra":"exterior",
  // Dulux
  "Dulux Aquatech Basecoat":"exterior","Promise Exterior Primer":"exterior","Weathershield Prime Coat":"exterior","Dulux Weathershield Prime Coat":"exterior","Weathershield Alkali Bloc PU+ Primer":"exterior","Dulux Weathershield Alkali Bloc PU+ Primer":"exterior","Weathershield":"exterior","Weathershield Powerflexx":"exterior","Weathershield Max":"exterior","Dulux Weathershield":"exterior","Dulux Weathershield Powerflexx":"exterior","Dulux Weathershield Max":"exterior","Aquatech Waterblock 2K":"exterior",
  // Jotun — official exterior catalogue
  "Jotashield Eterna":"exterior","Jotashield Nuovo":"exterior","Jotashield Tex Ultra":"exterior","Jotashield WaterXtreme Topcoat":"exterior","Jotashield ColourLast Silk":"exterior","Jotashield ColourLast Matt":"exterior","Jotashield":"exterior","Jotashield Alkali Resistant Primer":"exterior","Jotashield Penetrating Primer":"exterior","Jotashield Primer":"exterior","Exterior Putty":"exterior",
  "Royale Aspira":"interior","Royale Glitz":"interior","Royale Glitz Reserv":"interior","Royale Glitz Ultra Matt":"interior","Royale Shyne":"interior","Royale Shyne Advanced":"interior","Royale Lustre":"interior","Royale Health Shield":"interior","Royale Health Shield Asthma & Allergy Friendly":"interior","Royale Play Opaco Matt":"interior","Royale Play Pro":"interior","Apcolite All Protek Matte":"interior","Apcolite All Protek Shyne":"interior","One Dream Duracoat":"interior","One Dream Marble":"interior","One Dream Texture":"interior","One Pure Elegance":"interior","One Pure Elegance Matt":"interior","One Pure Elegance Shine":"interior","One Pure Legend":"interior","Calista Ever Wash Shine":"interior","Calista Ever Stay":"interior","Calista Ever Wash":"interior","Calista Ever Clear Matt":"interior","Calista Ever Clear":"interior","Charm Interior":"interior","Signature Interior":"interior","Fenomastic Wonderwall Lux":"interior","Fenomastic Wonderwall Life":"interior","Fenomastic My Home Rich Matt":"interior","Fenomastic My Home Smooth Silk":"interior","Fenomastic Pure Colours Silky Clean":"interior","Fenomastic Pure Colours":"interior","Fenomastic Hygiene":"interior","Fenomastic Emulsion Primer":"interior","Velvet Touch Diamond Glo":"interior","Velvet Touch Pearl Glo":"interior","Velvet Touch Platinum Glo":"interior",
  // Shalimar
  "Superlac Exterior":"exterior","Weatherproof Exterior":"exterior","Allwood PU Exterior":"exterior","Alldry Wall Fix 4":"exterior","Alldry Wallnroof 10":"exterior"
};

const VERIFIED_CATALOG_SEED: BrandProductRate[] = [
  ...([
    ["Asian Paints", "putty", ["Acrylic Wall Putty","TruCare Exterior Wall Putty"]],
    ["Asian Paints", "primer", ["Decoprime Wall Primer","TruCare Exterior Wall Primer","WoodTech Wood Primer","Metal Primer","TruCare Exterior Wall Primer Advanced"]],
    ["Asian Paints", "paint", ["Tractor Emulsion","Apcolite Premium Emulsion","Royale Matt","Royale Luxury Emulsion","Apex Exterior Emulsion","Apex Advanced Dust Proof","Apex Ultima","Apex Ultima Protek","Apex Ultima Protek Duralife","Apex Ultima Stretch","Apex Ultima Suprema","Ace Exterior Emulsion","Ace Advanced","Ace Shyne"]],
    ["Asian Paints", "enamel", ["Apcolite Premium Gloss Enamel"]], ["Asian Paints", "polish", ["WoodTech PU"]], ["Asian Paints", "waterproofing", ["Apex Ultima Protek"]],
    ["Berger Paints", "putty", ["Bison Wall Putty","Rangoli Putty","HomeShield Wall Putty"]],
    ["Berger Paints", "primer", ["BP White Primer","Interior Wall Primer","Exterior Wall Primer","WeatherCoat Exterior Primer","Silk Glamor Primer","Wood Primer","Metal Primer"]],
    ["Berger Paints", "paint", ["Bison Acrylic Distemper","Easy Clean","Silk Glamor Matt","Silk Luxury Emulsion","WeatherCoat Long Life","WeatherCoat Anti Dust","WeatherCoat All Guard","WeatherCoat Smooth","WeatherCoat Glow","WeatherCoat Tile Protect","Weathercoat Anti Dustt","Weathercoat Anti Dustt Kool","Weathercoat Glow","Weathercoat Champ"]],
    ["Berger Paints", "enamel", ["Luxol High Gloss Enamel"]], ["Berger Paints", "waterproofing", ["HomeShield Dampstop"]],
    ["Kansai Nerolac", "putty", ["Nerolac Wall Putty","Beauty Smooth Finish Putty","Excel Total Putty"]],
    ["Kansai Nerolac", "primer", ["Beauty Interior Primer","Exterior Primer","Excel Alkali Primer","Water Thinnable Cement Primer","Solvent Thinnable Cement Primer","Wood Primer","Red Oxide Metal Primer"]],
    ["Kansai Nerolac", "paint", ["Excel Total Floor Coat","Suraksha Plus","Suraksha Plus NXT","Suraksha Acrylic Exterior Emulsion","Neu Latex Exterior","Beauty Gold Washable","Beauty Smooth","Beauty Little Master","Beauty Silver","Impressions Kashmir","Impressions HD","Impressions Ultra HD","Excel Total","Excel Mica Marble","Excel Top Guard","Excel Anti-Peel","Excel Everlast"]],
    ["Kansai Nerolac", "enamel", ["Nerolac Synthetic Enamel","Nerolac Satin Enamel"]],
    ["Birla Opus", "putty", ["One Pro Smooth Putty","One Pro Putty+Primer","One Acrylic Putty","Style Wall Putty"]],
    ["Birla Opus", "primer", ["One Pro Smooth Primer","Calista Pro White Primer","Style Pro Hide Primer","Style Pro Fresh Primer","Prime I10 Interior Water Thinnable Wall Primer","Style Perfect Start Primer","Exterior Wall Primer","Wood Primer","Metal Primer"]],
    ["Birla Opus", "paint", ["One True Look","Calista Neo Star","Style Power Bright","Style Super Bright","Style Super Smooth","Style Color Smart","Style Color","One Pure Elegance","One Pure Elegance Matt","One Pure Elegance Shine","One Pure Legend","One Dream Duracoat","Calista Ever Wash Shine","Calista Ever Stay","Calista Ever Wash","Calista Ever Clear Matt","Calista Ever Clear","Alldry","Allwood","One Timeless Marmorino","One Timeless Marmorino Metallic","One Timeless Clay","One Timeless Natura","One Timeless Stone","One Dream Marble","One Dream Effects","One Dream Effects Metallic","One Dream Texture","Style Perfect Smart","Style Exterior Emulsion"]],
    ["Birla Opus", "enamel", ["Calista Sparkle Gloss","Calista Sparkle PU","Birla Opus Enamel"]], ["Birla Opus", "polish", ["Allwood PU Interior","Allwood PU Exterior"]], ["Birla Opus", "waterproofing", ["Alldry Wall Fix 4","Alldry Wallnroof 10"]],
    ["Indigo Paints", "putty", ["Super White Putty","Acrylic Wall Putty","Exterior Wall Putty"]], ["Indigo Paints", "primer", ["Water Thinnable Sealer Primer","Exterior Wall Primer","Water Thinnable Cement Primer","Interior Wall Primer","Wood Primer","Metal Primer"]], ["Indigo Paints", "paint", ["Interior Emulsion","Premium Interior Emulsion","Luxury Interior Emulsion","Exterior Emulsion","Dirtproof & Waterproof Exterior Emulsion","Dirtproof & Waterproof Exterior Laminate"]], ["Indigo Paints", "enamel", ["Gloss Enamel","PU Super Gloss Enamel"]],
    ["JSW Paints", "putty", ["Wall Putty","Acrylic Wall Putty","Exterior Wall Putty"]], ["JSW Paints", "primer", ["Interior Wall Primer","Exterior Wall Primer","Water Thinnable Primer","Wall Primer Exteriors","Profect Wall Primer Eco Exteriors","Wood Primer","Metal Primer"]], ["JSW Paints", "paint", ["Halo Majestic","Halo Majestic Lustre","Halo Majestic Luxury Emulsion","Halo Silk","Halo Acrylic Distemper","Elegant Exteriors","Regal Exteriors","Majestic Exteriors","Pixa Ultima","Pixa Excel","Pixa Advanced","Pixa Exterior Emulsion"]],
    ["Nippon Paint", "putty", ["Wall Putty","Odour-less Wall Putty","Exterior Wall Putty"]], ["Nippon Paint", "primer", ["Vinilex Primer","Interior Primer","Exterior Primer","Wall Sealer","Cement Primer","Dr Bond Efflorescence Resistant Sealer","Wood Primer","Metal Primer"]], ["Nippon Paint", "paint", ["Vinilex","Breeze","Breeze Ultra","Atom 2-in-1","Spot-less Plus","Odour-less Premium","Weatherbond","Weatherbond Pro","Weatherbond Advance","Weatherbond 8","Weatherbond Solareflect","Suno Xtra Dust Shield","DuraFresh Solo","Shogun Ultra","Suma Matt Enamel","Perfect Emulsion","Q-Shield"]],
    ["Dulux", "putty", ["Dulux Wall Putty","Dulux Promise Wall Putty","Dulux Aquatech Basecoat"]], ["Dulux", "primer", ["Dulux Promise Interior Primer","Dulux Promise SmartChoice Interior Primer","Dulux Weathershield Prime Coat","Dulux Promise Exterior Primer","Dulux Weathershield Alkali Bloc PU+ Primer","Dulux Solvent-based Cement Primer","Dulux Water-based Cement Primer","Dulux Quick Drying Primer","Dulux Red-oxide Metal Primer","Dulux Zinc Yellow Metal Primer","Duwel White Primer","Duwel Pink Wood Primer"]], ["Dulux", "paint", ["Dulux Promise SmartChoice Interior","Dulux Promise Sheen Interior","Dulux SuperClean","Dulux SuperClean 3in1","Dulux SuperCover","Dulux Velvet Touch Diamond Glo","Dulux Velvet Touch Pearl Glo","Dulux Velvet Touch Platinum Glo","Dulux Velvet Touch Eterna Tru Colour+","Dulux Ambiance","Dulux Weathershield Powerflexx","Dulux Weathershield","Dulux Weathershield Max"]], ["Dulux", "enamel", ["Dulux Gloss Enamel"]], ["Dulux", "waterproofing", ["Aquatech Waterblock 2K"]],
    ["Jotun", "putty", ["Jotun Wall Putty","Interior Putty","Exterior Putty"]], ["Jotun", "primer", ["Fenomastic Emulsion Primer","Jotashield Alkali Resistant Primer","Jotashield Penetrating Primer","Jotashield Primer","Pilot WF Primer","Wood Primer","Metal Primer"]], ["Jotun", "paint", ["Fenomastic Wonderwall Lux","Fenomastic Wonderwall Life","Fenomastic My Home Rich Matt","Fenomastic My Home Smooth Silk","Majestic True Beauty","Jotun Essence","Jotashield Eterna","Jotashield Nuovo","Jotashield Tex Ultra","Jotashield WaterXtreme Topcoat","Jotashield ColourLast Silk","Jotashield ColourLast Matt"]],
    ["Shalimar Paints", "paint", ["Superlac Exterior","Weatherproof Exterior","Charm Interior","Signature Interior"]],
      ["Asian Paints", "paint", ["Tractor Emulsion Advanced","Apcolite All Protek Matte","Apcolite All Protek Shyne","Royale Aspira","Royale Glitz","Royale Glitz Reserv","Royale Glitz Ultra Matt","Royale Shyne","Royale Shyne Advanced","Royale Lustre","Royale Health Shield","Royale Health Shield Asthma & Allergy Friendly","Royale Play Opaco Matt","Royale Play Pro"]],
    ["Asian Paints", "primer", ["Royale Wall Base Coat","TruCare Interior Wall Primer - Water Thinnable"]],
    ["Birla Opus", "paint", ["One Pure Elegance","One Pure Elegance Matt","One Pure Elegance Shine","One Pure Legend","Calista Ever Wash Shine","Calista Ever Stay","Calista Ever Wash","Calista Ever Clear Matt","Calista Ever Clear","One Timeless Marmorino","One Timeless Marmorino Metallic","One Timeless Clay","One Timeless Natura","One Timeless Stone","One Dream Marble","One Dream Effects","One Dream Effects Metallic","One Dream Texture"]],
    ["Indigo Paints", "paint", ["Interior Acrylic Laminate","Interior Acrylic Distemper","Interior Wall Primer Paint","Premium Interior Emulsion","Luxury Interior Emulsion","Dirtproof & Waterproof Interior Emulsion"]],
    ["JSW Paints", "paint", ["Halo Majestic","Halo Majestic Lustre","Halo Majestic Luxury Emulsion","Halo Silk","Halo Acrylic Distemper"]],
    ["Nippon Paint", "paint", ["Breeze Ultra","Spot-less Plus","Odour-less Premium","Vinilex","Perfect Emulsion","Q-Shield"]],
    ["Dulux", "paint", ["Dulux Promise SmartChoice Interior","Dulux Promise Sheen Interior","Dulux SuperClean","Dulux SuperClean 3in1","Dulux SuperCover","Dulux Velvet Touch Diamond Glo","Dulux Velvet Touch Pearl Glo","Dulux Velvet Touch Platinum Glo","Dulux Velvet Touch Eterna Tru Colour+","Dulux Ambiance"]],
    ["Jotun", "paint", ["Fenomastic Wonderwall Lux","Fenomastic Wonderwall Life","Fenomastic My Home Rich Matt","Fenomastic My Home Smooth Silk","Fenomastic Pure Colours Silky Clean","Fenomastic Pure Colours","Fenomastic Hygiene"]],
    ["Jotun", "primer", ["Fenomastic Emulsion Primer"]],
    ["Shalimar Paints", "paint", ["Charm Interior","Signature Interior"]],
    ["Shalimar Paints", "paint", ["Hero Insignia","Hero 5 In 1","Silk Sign Interior Emulsion","Silk Eco Interior Emulsion","Superlac Stay Clean Premium Emulsion","Superlac Advance Emulsion","No.1 Silk","Smart Bharat Interior And Exterior Paint","No.1 Premium Acrylic Distemper","Mela Acrylic Distemper"]],
    ["Shalimar Paints", "primer", ["Water Thinnable Cement Primer","Interior Exterior Acrylic Primer"]],
    ["Universal Paints / Uniguard", "waterproofing", ["2K Flexi","2K Fondo","2K Plus","2K Slurry","2K Ultra B","Bituguard Cryl","Bituguard Emulsion"]],
] as Array<[string, BrandProductRate["category"], string[]]>).flatMap(([brand, category, products]) => products.map((product, i) => {
    const surface = CATALOG_SURFACE_OVERRIDES[`${brand}|${product}`] || CATALOG_SURFACE_OVERRIDES[String(product)] || (category === "enamel" || category === "polish" ? "interior" : "interior");
    return {id:`seed-${String(brand).replace(/\W/g,'')}-${category}-${i}`,surface,paintingType:"fresh",packageId:"custom",brand,category,product,materialType:product,rate:0} as BrandProductRate;
  }))
];


const VERIFIED_REPAINT_CATALOG: BrandProductRate[] = VERIFIED_CATALOG_SEED.map((r,i)=>({
  ...r, id:`repaint-${r.id}-${i}`, paintingType:"repaint" as const
}));

export function getBrandProductRates(): BrandProductRate[] {
  const dedupe=(items: BrandProductRate[]) => {
    const m=new Map<string,BrandProductRate>();
    for(const r of items||[]){
      const key=[r.surface,r.paintingType||"fresh",r.packageId||"custom",r.brand,String(r.category),String(r.product||"").trim().toLowerCase()].join("|");
      if(!m.has(key)) m.set(key,r);
    }
    return [...m.values()];
  };
  try {
    const raw=localStorage.getItem(BRAND_PRODUCT_STORAGE_KEY);
    const parsed=raw?JSON.parse(raw):[];
    // Merge the current verified manufacturer catalogue into existing saved rates.
    // This deliberately preserves admin-entered rates while adding newly verified products.
    if(Array.isArray(parsed) && parsed.length) return dedupe([...parsed,...VERIFIED_CATALOG_SEED,...VERIFIED_REPAINT_CATALOG]);
    return dedupe([...VERIFIED_CATALOG_SEED,...VERIFIED_REPAINT_CATALOG]);
  } catch { return dedupe([...VERIFIED_CATALOG_SEED,...VERIFIED_REPAINT_CATALOG]); }
}
export function saveBrandProductRates(items: BrandProductRate[]): boolean {
  try { localStorage.setItem(BRAND_PRODUCT_STORAGE_KEY,JSON.stringify(items||[])); return true; } catch { return false; }
}
export function getCatalogProductSuggestions(brand: string, category: BrandProductRate["category"], surface: "interior"|"exterior", paintingType: "fresh"|"repaint" = "fresh"): string[] {
  return [...new Set(getBrandProductRates()
    .filter(r=>r.surface===surface && (r.paintingType===paintingType || !r.paintingType) && r.brand===brand && r.category===category)
    .map(r=>String(r.product||"").trim()).filter(Boolean))];
}

export function findBrandProductRate(query: Partial<BrandProductRate>): BrandProductRate | undefined {
  const norm=(v:any)=>String(v||"").trim().toLowerCase();
  return getBrandProductRates().find(r=>
    norm(r.surface)===norm(query.surface) && norm(r.paintingType)===norm(query.paintingType) &&
    norm(r.packageId)===norm(query.packageId) && norm(r.brand)===norm(query.brand) &&
    norm(r.category)===norm(query.category) && norm(r.product)===norm(query.product)
  );
}
